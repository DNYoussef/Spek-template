# Version & Run Log System Documentation

## Overview

The Version & Run Log System provides enterprise-grade version tracking and audit trails for all agent file operations in the SPEK Enhanced Development Platform. Every file modification is tracked with semantic versioning, content hashing, and comprehensive metadata.

## Key Features

- **Automatic Version Management**: Semantic versioning with intelligent bump detection
- **Content Integrity**: SHA-256 based deterministic hashing (7-character representation)
- **Multi-Format Support**: Works with 30+ file types with appropriate comment styles
- **Idempotency Detection**: Prevents duplicate entries for unchanged content
- **Audit Trail**: Complete JSON sidecar logging for compliance and tracking
- **Self-Healing**: Automatic footer repair and validation
- **CI/CD Integration**: Pre-commit hooks and pipeline validation

## Architecture

```
src/version-log/
├── VersionLogManager.py      # Main coordinator
├── ContentHasher.py          # Deterministic hashing
├── SemverManager.py          # Semantic versioning
├── FooterRenderer.py         # Multi-format rendering
├── comment-styles.json       # File type mappings
├── middleware/
│   └── AgentFooterMiddleware.py  # Agent integration
└── __init__.py              # Package exports
```

## Footer Format

### Standard Footer Structure

```markdown
<!-- AGENT FOOTER BEGIN: DO NOT EDIT ABOVE THIS LINE -->
## Version & Run Log
| Version | Timestamp (ISO-8601)     | Agent/Model | Change Summary | Artifacts Changed | Status | Warnings/Notes | Cost (USD) | Content Hash |
|--------:|---------------------------|-------------|----------------|-------------------|--------|----------------|-----------:|--------------|
| 1.0.0   | 2025-09-24T15:12:03-04:00 | agent@Model | Description   | files            | OK     | —              | 0.00      | 7chars      |

### Receipt
- status: OK | PARTIAL | BLOCKED
- reason_if_blocked: —
- run_id: unique-id
- inputs: ["source-files"]
- tools_used: ["mcp-servers", "tools"]
- versions: {"model":"version","prompt":"version"}
<!-- AGENT FOOTER END: DO NOT EDIT BELOW THIS LINE -->
```

## Usage

### Basic Usage

```python
from version_log import VersionLogManager

# Initialize manager
manager = VersionLogManager()

# Update file with footer
manager.update_file(
    file_path="src/example.py",
    agent_meta="coder@GPT-5",
    change_summary="Added validation logic",
    artifacts_changed=["src/example.py", "tests/test_example.py"],
    status="OK",
    cost_usd=0.12,
    versions={"model": "gpt-5", "prompt": "v18"},
    inputs=["SPEC.md", "plan.json"],
    tools_used=["claude-flow", "memory", "github"]
)
```

### Agent Integration

```python
from version_log.middleware import AgentFooterMiddleware

# Get middleware instance
middleware = AgentFooterMiddleware()

# Process agent action
action = {
    'type': 'write_file',
    'file_path': 'src/feature.py',
    'agent': {
        'name': 'developer',
        'model': 'GPT-5',
        'version': '1.0'
    },
    'description': 'Implement new feature',
    'cost': 0.08,
    'tools_used': ['editor', 'linter']
}

# Automatically adds footer
processed = middleware.process_agent_action(action)
```

### Validation

```python
# Validate single file
result = manager.validate_footer("src/example.py")
if result['valid']:
    print(f"Footer valid. Version: {result['last_version']}")
else:
    print(f"Footer invalid: {result['error']}")

# Batch validation
middleware = AgentFooterMiddleware()
results = middleware.validate_file_footers([
    "src/file1.py",
    "src/file2.js",
    "docs/README.md"
])

print(f"Valid: {len(results['valid'])}")
print(f"Invalid: {len(results['invalid'])}")
```

## File Type Support

The system supports 30+ file types with appropriate comment styles:

| Language | Extensions | Comment Style |
|----------|------------|---------------|
| Python | `.py` | `# ...` |
| JavaScript/TypeScript | `.js`, `.ts`, `.jsx`, `.tsx` | `/* ... */` |
| Markdown/HTML | `.md`, `.html` | `<!-- ... -->` |
| Shell/Bash | `.sh`, `.bash` | `# ...` |
| YAML | `.yaml`, `.yml` | `# ...` |
| Java/C/C++ | `.java`, `.c`, `.cpp`, `.h` | `/* ... */` |
| Go | `.go` | `/* ... */` |
| Rust | `.rs` | `// ...` |
| Ruby | `.rb` | `# ...` |
| SQL | `.sql` | `-- ...` |

## Version Management

### Semantic Versioning Rules

- **MAJOR**: Breaking changes (removed functions, changed signatures)
- **MINOR**: New features, schema changes, structural modifications
- **PATCH**: Bug fixes, minor content changes, documentation updates
- **NO_CHANGE**: Idempotent operations (same content hash)

### Change Detection

```python
from version_log import SemverManager, ChangeType

manager = SemverManager()

# Automatic detection
change_type = manager.detect_change_type(
    old_content="def foo(): pass",
    new_content="def foo(x): return x",
    metadata={'breaking_change': False}
)
# Returns: ChangeType.MINOR (signature changed)

# Manual bumping
new_version = manager.bump_version("1.2.3", ChangeType.MINOR)
# Returns: "1.3.0"
```

## Content Hashing

### Hash Calculation

1. Strip footer from content
2. Normalize line endings to `\n`
3. Remove trailing whitespace from lines
4. Remove trailing empty lines
5. Compute SHA-256 hash
6. Return first 7 characters

```python
from version_log import ContentHasher

hasher = ContentHasher()

# Compute hash (excludes footer by default)
hash_value = hasher.compute_hash(file_content)
# Returns: "a1b2c3d" (7 characters)

# Verify hash
is_valid = hasher.verify_hash(file_content, expected_hash)
```

## CI/CD Integration

### Pre-commit Hook

Add to `.git/hooks/pre-commit`:

```bash
#!/bin/bash
python scripts/hooks/pre-commit-footer-check.py
```

### GitHub Actions

```yaml
- name: Validate Version Footers
  run: |
    python scripts/hooks/pre-commit-footer-check.py

- name: Check Audit Trail
  run: |
    test -f .claude/.artifacts/run_logs.jsonl
    python -c "import json; [json.loads(l) for l in open('.claude/.artifacts/run_logs.jsonl')]"
```

## Audit Trail

### JSON Sidecar Format

Each operation creates an entry in `.claude/.artifacts/run_logs.jsonl`:

```json
{
  "run_id": "abc12345",
  "file": "src/example.py",
  "pre_footer_hash": "a1b2c3d",
  "status": "OK",
  "version": "1.2.3",
  "change_summary": "Added validation",
  "artifacts_changed": ["src/example.py"],
  "timestamp": "2025-09-24T15:12:03",
  "agent": "coder@GPT-5",
  "tools_used": ["editor", "linter"],
  "cost_usd": 0.12,
  "inputs": ["SPEC.md"]
}
```

## Error Handling

### Status Codes

- **OK**: Operation completed successfully
- **PARTIAL**: Operation partially completed (e.g., idempotent, warnings)
- **BLOCKED**: Operation failed (with reason)

### Auto-Repair

```python
# Repair corrupted footer
success = manager.repair_footer("src/corrupted.py")

# Enable auto-repair in middleware
middleware = AgentFooterMiddleware()
middleware.auto_repair = True
```

## Best Practices

1. **Always include meaningful change summaries** (≤80 characters)
2. **List all affected artifacts** in artifacts_changed
3. **Track actual costs** for resource accounting
4. **Use appropriate status codes** (OK, PARTIAL, BLOCKED)
5. **Maintain version history** (max 20 rows per file)
6. **Validate footers in CI/CD** pipelines
7. **Review audit trails regularly** for compliance

## Integration with SPEK Platform

### Theater Detection

Footer status provides evidence of real work:
- Hash changes confirm actual modifications
- Version progression shows iterative development
- Audit trail proves work timeline

### 3-Loop System

- **Loop 1 (Planning)**: Footers track spec evolution
- **Loop 2 (Development)**: Footers track implementation
- **Loop 3 (Quality)**: Footers track validation results

### Quality Gates

```python
# Quality gate validation
validation = manager.validate_footer(file_path)
if not validation['valid']:
    raise QualityGateError(f"Footer validation failed: {validation['error']}")
```

### Defense Industry Compliance

- Complete audit trail for NASA POT10
- Cryptographic integrity via content hashing
- Full attribution with agent/model tracking
- Cost tracking for resource accounting

## Troubleshooting

### Common Issues

1. **Hash Mismatch**: Content changed without footer update
   - Solution: Run `manager.repair_footer(file_path)`

2. **Missing Footer**: File has no footer
   - Solution: Use `manager.update_file()` to add

3. **Too Many Rows**: Exceeds 20-row limit
   - Solution: Automatic rotation handles this

4. **Invalid Version**: Version format incorrect
   - Solution: Check semver format (MAJOR.MINOR.PATCH)

### Debug Mode

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Detailed validation
result = manager.validate_footer(file_path)
print(json.dumps(result, indent=2))

# Check sidecar logs
with open('.claude/.artifacts/run_logs.jsonl') as f:
    for line in f:
        print(json.dumps(json.loads(line), indent=2))
```

## Performance

- **Hash Computation**: ~1ms per file
- **Footer Update**: ~5ms per file
- **Validation**: ~2ms per file
- **Overhead**: <10ms per operation
- **Storage**: ~500 bytes per footer

## Security Considerations

1. **Never include secrets** in change summaries or inputs
2. **Sanitize file paths** before logging
3. **Validate agent authentication** before updates
4. **Protect audit logs** with appropriate permissions
5. **Use secure hashing** (SHA-256)

## Future Enhancements

- [ ] Distributed footer synchronization
- [ ] Blockchain integration for immutable audit trail
- [ ] Machine learning for change type detection
- [ ] Real-time dashboard for version tracking
- [ ] Integration with version control systems
- [ ] Automated compliance reporting

## Support

For issues or questions:
- Check [FOOTER-INSTRUCTIONS.md](../src/version-log/FOOTER-INSTRUCTIONS.md)
- Review test suite: `tests/version-log/test_version_log_system.py`
- Submit issues to the SPEK project repository