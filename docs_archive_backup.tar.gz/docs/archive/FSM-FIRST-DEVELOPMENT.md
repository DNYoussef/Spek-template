# FSM-First Development Guide

## Overview

The SPEK platform now **requires** state-machine thinking for all development. Every feature must be designed as a finite state machine (FSM) with explicit states, events, and transitions before any code is written.

## Why FSM-First?

### Benefits
1. **Predictable Behavior**: All possible states and transitions are known upfront
2. **Easier Testing**: Every transition can be tested independently
3. **Better Debugging**: State history and transition logs make issues obvious
4. **Reduced Complexity**: Logic is isolated within states, not scattered
5. **Documentation**: The FSM specification IS the documentation

### Problems Avoided
- Spaghetti code with complex conditional logic
- Race conditions and timing issues
- Incomplete error handling
- Untestable state management
- Hidden edge cases

## The FSM Development Process

### Step 1: Design Your State Machine

**Command**: `/fsm:design "feature description"`

This generates:
- `fsm_spec.yaml` - Complete FSM specification
- `docs/fsm_diagram.svg` - Visual state diagram
- `tests/fsm/transition_matrix.json` - Test cases

**Example**:
```bash
/fsm:design "User authentication with MFA support"
```

### Step 2: Review and Refine

Check the generated specification:
```yaml
fsm:
  name: "UserAuthentication"

  states:
    - id: "LOGGED_OUT"
      description: "User not authenticated"
    - id: "LOGGING_IN"
      description: "Authentication in progress"
    - id: "MFA_REQUIRED"
      description: "Awaiting MFA verification"
    - id: "LOGGED_IN"
      description: "User authenticated"
    - id: "ERROR"
      description: "Authentication error"

  events:
    - id: "LOGIN"
    - id: "MFA_SUBMIT"
    - id: "LOGOUT"
    - id: "TIMEOUT"
    - id: "ERROR"

  transitions:
    LOGGED_OUT:
      LOGIN:
        target: "LOGGING_IN"
        guard: "hasValidCredentials"
    LOGGING_IN:
      SUCCESS: "LOGGED_IN"
      MFA_REQUIRED: "MFA_REQUIRED"
      ERROR: "ERROR"
    # ... etc
```

### Step 3: Generate Implementation

**Command**: `/fsm:generate`

This creates:
```
src/
  fsm/
    types.ts              # StateId and EventType enums
    TransitionHub.ts      # Centralized state management
    guards.ts            # Transition validators
  states/
    LoggedOutState.ts    # One file per state
    LoggingInState.ts
    MFARequiredState.ts
    LoggedInState.ts
    ErrorState.ts
tests/
  fsm/
    StateMachine.test.ts
```

### Step 4: Implement State Logic

Each state file follows this pattern:

```typescript
// src/states/LoggingInState.ts
export class LoggingInState implements StateContract {
  init(ctx: Context): void {
    // Entry actions
    ctx.ui.showSpinner();
    ctx.api.startAuthRequest();
  }

  update(ctx: Context, event: Event): StateId | "REMAIN" {
    switch(event.type) {
      case EventType.SUCCESS:
        ctx.user = event.payload.user;
        return StateId.LOGGED_IN;

      case EventType.MFA_REQUIRED:
        ctx.mfaChallenge = event.payload.challenge;
        return StateId.MFA_REQUIRED;

      case EventType.ERROR:
        ctx.error = event.payload.error;
        return StateId.ERROR;

      case EventType.TIMEOUT:
        return StateId.LOGGED_OUT;

      default:
        return "REMAIN";
    }
  }

  shutdown(ctx: Context): void {
    // Exit actions
    ctx.ui.hideSpinner();
    ctx.api.cancelAuthRequest();
  }

  checkInvariants(ctx: Context): boolean {
    return ctx.api.isRequestActive();
  }
}
```

### Step 5: Validate Implementation

**Command**: `/fsm:validate --strict`

This checks:
- ✅ All states reachable
- ✅ No deadlock states
- ✅ 100% transition coverage
- ✅ All guards implemented
- ✅ State contracts fulfilled
- ✅ Proper isolation

### Step 6: Test All Transitions

**Command**: `/fsm:test-matrix`

Runs generated tests for every possible transition:
```
✓ LOGGED_OUT + LOGIN → LOGGING_IN
✓ LOGGED_OUT + LOGOUT → REMAIN
✓ LOGGING_IN + SUCCESS → LOGGED_IN
✓ LOGGING_IN + MFA_REQUIRED → MFA_REQUIRED
✓ LOGGING_IN + ERROR → ERROR
... (all combinations)
```

## FSM Patterns

### Pattern 1: Simple Sequential Flow
```
IDLE → PROCESSING → COMPLETE
        ↓
      ERROR
```

### Pattern 2: Cyclical Process
```
READY ← COMPLETE
  ↓        ↑
START → WORKING
```

### Pattern 3: Hierarchical States
```
CONNECTED
  ├─ IDLE
  ├─ ACTIVE
  └─ SUSPENDED
DISCONNECTED
  ├─ RECONNECTING
  └─ OFFLINE
```

### Pattern 4: Concurrent Regions
```
Region1: UI_STATE (LOADING | READY | ERROR)
Region2: DATA_STATE (FETCHING | CACHED | STALE)
```

## Common FSM Anti-Patterns to Avoid

### ❌ Logic in the Loop
```javascript
// WRONG
while(running) {
  if (state === "processing") {
    // Logic here - NO!
  }
}
```

### ✅ Logic in States
```javascript
// RIGHT
class ProcessingState {
  update(ctx, event) {
    // Logic here - YES!
  }
}
```

### ❌ String Events
```javascript
// WRONG
if (event === "start") { }
```

### ✅ Enum Events
```javascript
// RIGHT
if (event.type === EventType.START) { }
```

### ❌ Scattered Transitions
```javascript
// WRONG - transitions in multiple places
class ComponentA {
  handleClick() { this.state = "active"; }
}
class ComponentB {
  handleTimeout() { this.state = "idle"; }
}
```

### ✅ Centralized Transitions
```javascript
// RIGHT - single transition hub
class TransitionHub {
  transition(event) {
    const next = this.states[current].update(ctx, event);
    this.switchState(next);
  }
}
```

## Integration with 3-Loop System

### Loop 1: Discovery & Planning
- Use `/fsm:design` during specification phase
- Include FSM spec in risk analysis
- Plan states before implementation

### Loop 2: Development
- Generate with `/fsm:generate`
- Implement states following contracts
- Use theater detection on state implementations

### Loop 3: Quality & Debugging
- Validate with `/fsm:validate`
- Test all transitions
- Monitor state metrics in production

## FSM Quality Gates

All FSM implementations must pass:

| Gate | Requirement | Command |
|------|-------------|---------|
| Coverage | 100% transition coverage | `/fsm:validate --coverage` |
| Reachability | All states reachable | `/fsm:validate --reachability` |
| Isolation | One file per state | `/fsm:validate --isolation` |
| Contracts | All methods implemented | `/fsm:validate --contracts` |
| Guards | All guards defined | `/fsm:validate --guards` |
| Testing | All transitions tested | `/fsm:test-matrix` |

## Real-World Examples

### Example 1: File Upload
```yaml
states:
  - IDLE
  - SELECTING
  - VALIDATING
  - UPLOADING
  - PROCESSING
  - COMPLETE
  - ERROR

events:
  - SELECT_FILE
  - FILE_VALID
  - FILE_INVALID
  - UPLOAD_PROGRESS
  - UPLOAD_COMPLETE
  - PROCESS_COMPLETE
  - RETRY
  - CANCEL
```

### Example 2: Shopping Cart
```yaml
states:
  - EMPTY
  - BROWSING
  - ADDING_ITEM
  - REVIEWING
  - CHECKING_OUT
  - PAYMENT
  - CONFIRMED
  - CANCELLED

events:
  - ADD_ITEM
  - REMOVE_ITEM
  - UPDATE_QUANTITY
  - PROCEED_CHECKOUT
  - ENTER_PAYMENT
  - CONFIRM_ORDER
  - CANCEL_ORDER
```

### Example 3: WebSocket Connection
```yaml
states:
  - DISCONNECTED
  - CONNECTING
  - CONNECTED
  - RECONNECTING
  - ERROR
  - CLOSED

events:
  - CONNECT
  - CONNECTION_OPEN
  - CONNECTION_ERROR
  - CONNECTION_CLOSE
  - RECONNECT
  - GIVE_UP
```

## Debugging FSM Issues

### Use State History
```javascript
const history = transitionHub.getTransitionHistory(10);
// Shows last 10 transitions with timestamps
```

### Enable Debug Overlay
```javascript
if (DEBUG) {
  showOverlay({
    currentState: fsm.getCurrentState(),
    recentTransitions: fsm.getHistory(5),
    invariants: fsm.checkInvariants()
  });
}
```

### Analyze Transition Patterns
```bash
/fsm:analyze --patterns
# Shows common transition sequences
# Identifies unusual patterns
# Suggests optimizations
```

## FSM Performance Considerations

### State Transition Budget
- Target: <1ms per transition
- Measure: Performance.now() in update()
- Alert: Log slow transitions

### Memory Management
- Keep state objects lightweight
- Clear resources in shutdown()
- Use object pools for frequent transitions

### Optimization Techniques
1. Lazy state initialization
2. Transition caching
3. Event batching
4. State preloading

## Migration Guide

### Converting Existing Code to FSM

1. **Identify Current States**
   - Look for boolean flags
   - Find if/else chains
   - Locate switch statements

2. **Extract Events**
   - User interactions
   - API responses
   - Timers/intervals
   - External triggers

3. **Map Transitions**
   - When do states change?
   - What triggers changes?
   - What guards exist?

4. **Generate FSM**
   ```bash
   /fsm:migrate "existing_code.ts"
   ```

5. **Refactor Incrementally**
   - Start with clear boundaries
   - Move logic into states
   - Centralize transitions
   - Add guards and invariants

## Tooling Support

### VS Code Extension
- Syntax highlighting for fsm_spec.yaml
- State diagram preview
- Transition navigation
- Guard validation

### CLI Tools
```bash
# Analyze FSM complexity
fsm-analyze complexity fsm_spec.yaml

# Generate documentation
fsm-docs generate fsm_spec.yaml

# Simulate execution
fsm-simulate --events events.json

# Profile performance
fsm-profile --runtime 60s
```

## Best Practices Checklist

- [ ] Design FSM before coding
- [ ] One state per file
- [ ] Centralized transitions only
- [ ] Use enums for events/states
- [ ] Implement all contract methods
- [ ] Define guards for complex transitions
- [ ] Include error recovery states
- [ ] Test every transition
- [ ] Log all transitions
- [ ] Monitor in production
- [ ] Document invariants
- [ ] Profile performance

## Conclusion

FSM-First Development is now the standard in SPEK. By thinking in states and transitions from the beginning, you create more maintainable, testable, and reliable software. The tooling ensures you follow best practices, and the quality gates guarantee correctness.

Remember: **If it's not a state machine, it's not good architecture.**

---

*Version: 1.0.0 | Status: Production Ready | FSM Compliance: Required*